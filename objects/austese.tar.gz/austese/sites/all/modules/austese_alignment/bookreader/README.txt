The Internet Archive BookReader is used to view books from the Internet Archive
online and can also be used to view other books.

Developer documentation:
http://openlibrary.org/dev/docs/bookreader

Hosted source code:
http://github.com/openlibrary/bookreader

The source code license is AGPL v3, as described in the LICENSE file.
