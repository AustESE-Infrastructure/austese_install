
Ext.define('TableApparatusApp.model.VersionListModel', {
    extend: 'Ext.data.Model',

    fields: ['version','longname']
});